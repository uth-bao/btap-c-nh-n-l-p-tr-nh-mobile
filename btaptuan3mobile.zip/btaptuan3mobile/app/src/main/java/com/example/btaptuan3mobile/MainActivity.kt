package com.example.btaptuan3mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.* // Hoặc androidx.compose.material nếu bạn đang dùng phiên bản Material cũ hơn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

// Annotation này cần thiết nếu bạn sử dụng các API "thử nghiệm" từ Material3
@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { // Đã sửa lỗi chính tả từ 'fun fun onCreate' thành 'override fun onCreate'
        super.onCreate(savedInstanceState)
        setContent {
            MyAPP()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class) // Cần thiết nếu OutlinedTextField và các Material3 Composables khác là Experimental
@Composable
fun MyAPP() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }
        composable("text") { TextScreen() }
        composable("image") { ImageScreen() }
        composable("textfield") { TextFieldScreen() }
        composable("passwordfield") { PasswordFieldScreen() }
        composable("column") { ColumnLayoutScreen() }
        composable("row") { RowScreen() }
    }
}

@Composable
fun HomeScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "UI Components List",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Button(onClick = { navController.navigate("text") }) {
            Text("Text")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { navController.navigate("image") }) {
            Text("Image")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { navController.navigate("textfield") }) {
            Text("TextField")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { navController.navigate("passwordfield") }) {
            Text("PasswordField")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { navController.navigate("column") }) {
            Text("Column Layout")
        }
        Spacer(Modifier.height(8.dp))

        Button(onClick = { navController.navigate("row") }) {
            Text("Row Layout")
        }
    }
}

@Composable
fun TextScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "The quick brown fox jumps over the lazy dog.",
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Composable
fun ImageScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Demo Image:",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        // Đảm bảo rằng bạn có một hình ảnh có tên 'ic_launcher_foreground' trong thư mục res/drawable
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "Demo Image",
            modifier = Modifier.size(150.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Hoặc ảnh từ URL (yêu cầu thư viện Coil/Glide):",
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        // Để hiển thị ảnh từ URL, bạn cần thêm dependency 'coil-compose' hoặc 'glide-compose'
        // vào file build.gradle.kts (app) và sử dụng AsyncImage. Ví dụ với Coil:
        /*
        AsyncImage(
            model = "https://caohoc.uth.edu.vn/content/uploads/2023/04/UTH-logo.png",
            contentDescription = "UTH Logo",
            modifier = Modifier.size(150.dp)
        )
        */
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextFieldScreen() {
    val textState = remember { mutableStateOf(TextFieldValue()) }
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "TextField:",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        OutlinedTextField(
            value = textState.value,
            onValueChange = { textState.value = it },
            label = { Text("Thông tin nhập") },
            placeholder = { Text("Tự động cập nhật dữ liệu theo thời gian") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Bạn đã nhập: ${textState.value.text}",
            fontSize = 16.sp
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordFieldScreen() {
    val passwordState = remember { mutableStateOf(TextFieldValue()) }
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "PasswordField:",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        OutlinedTextField(
            value = passwordState.value,
            onValueChange = { passwordState.value = it },
            label = { Text("Mật khẩu") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Mật khẩu đã nhập: ${passwordState.value.text}",
            fontSize = 16.sp
        )
    }
}

@Composable
fun ColumnLayoutScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Ví dụ về Column Layout (sắp xếp dọc):",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Column(
            modifier = Modifier
                .width(200.dp)
                .background(Color.LightGray)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Item 1", modifier = Modifier.background(Color.Cyan).padding(8.dp))
            Text("Item 2", modifier = Modifier.background(Color.Green).padding(8.dp))
            Text("Item 3", modifier = Modifier.background(Color.Magenta).padding(8.dp))
        }
    }
}

@Composable
fun RowScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Ví dụ về Row Layout (sắp xếp ngang):",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .padding(4.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .padding(4.dp)
                        .background(MaterialTheme.colorScheme.secondary)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyAPP()
}