package com.example.uthsmarttasks;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

public class ProfileActivity extends AppCompatActivity {

    EditText nameEditText, emailEditText, dobEditText;
    Button backButton;
    ImageView avatarImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        dobEditText = findViewById(R.id.dobEditText);
        backButton = findViewById(R.id.backButton);
        avatarImageView = findViewById(R.id.avatarImageView);

        // Lấy thông tin từ tài khoản Google
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null) {
            nameEditText.setText(account.getDisplayName());
            emailEditText.setText(account.getEmail());
            emailEditText.setEnabled(false); // Không cho chỉnh email

            if (account.getPhotoUrl() != null) {
                Glide.with(this)
                        .load(account.getPhotoUrl())
                        .circleCrop()
                        .into(avatarImageView);
            }
        }

        // Hardcode ngày sinh mẫu
        dobEditText.setText("23/05/2005");

        // Xử lý nút Back
        backButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(ProfileActivity.this, MainActivity.class));
            finish();
        });
    }
}
